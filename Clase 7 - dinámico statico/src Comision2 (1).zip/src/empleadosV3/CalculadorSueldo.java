package empleadosV3;

public abstract class CalculadorSueldo {

	public abstract double calcularSueldo(Empleado ee);
}
