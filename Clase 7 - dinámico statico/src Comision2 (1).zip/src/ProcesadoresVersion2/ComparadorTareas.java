package ProcesadoresVersion2;

public abstract class ComparadorTareas {

	public abstract boolean compare(Tarea t1, Tarea ta);
}
