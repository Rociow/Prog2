package figuras;

public class AdministradorFiguras {

	public void imprimir(Figura ff) {
		System.out.println(ff.getDatosCompletos());
	    
	}
}
